// TutorConnectify App JavaScript - Hybrid V1 Glassmorphism with V2 Professional Colors
class TutorConnectifyApp {
    constructor() {
        this.tutors = [];
        this.filteredTutors = [];
        this.favorites = this.loadFavorites();
        this.currentPage = 'home';
        this.deferredPrompt = null;
        this.contactCount = this.loadContactCount();
        this.maxFreeContacts = 5;
        this.currentRegistrationStep = 1;
        
        this.init();
    }

    init() {
        this.loadTutorData();
        this.setupEventListeners();
        this.setupPWA();
        this.renderHomePage();
    }

    // Load tutor data
    loadTutorData() {
        // Enhanced tutor data from the provided JSON
        this.tutors = [
            {
                "id":"t1",
                "status":"approved",
                "name":"Arjun Mehta",
                "photoUrl":"/images/tutors/arjun.jpg",
                "phone":"+919876543210",
                "whatsapp":"+919876543210",
                "email":"arjun.maths@example.com",
                "location":{"city":"Mumbai","area":"Andheri"},
                "qualifications":[{"degree":"M.Sc Mathematics","institution":"IIT Bombay","year":2018}],
                "experienceYears":5,
                "subjects":[{"subject":"Mathematics","gradeLevels":["High School","College"]}],
                "languages":["English","Hindi","Marathi"],
                "pricing":{"hourlyMin":800,"hourlyMax":1200},
                "teachingModes":{"homeVisit":true,"online":true,"atTutorPlace":false},
                "availability":[{"day":"Mon","timeWindows":[{"start":"16:00","end":"20:00"}]}],
                "contactPreferences":{"bestTimes":["Evening"],"avgResponseTime":"2h"},
                "ratings":{"average":4.8,"count":45,"breakdown":{"5":35,"4":8,"3":2,"2":0,"1":0}},
                "reviews":[],
                "about":{"bio":"Passionate mathematics tutor with 5+ years experience. Specialized in making complex concepts simple and engaging for students of all levels.","philosophy":"Conceptual clarity over memorization","reasons":"Love seeing students succeed and build confidence"},
                "areasServed":["Andheri","Bandra","Juhu","Goregaon"],
                "createdAt":1627815600,
                "updatedAt":1692082200,
                "premium":false
            },
            {
                "id":"t2",
                "status":"approved",
                "name":"Sara Khan",
                "photoUrl":"/images/tutors/sara.jpg",
                "phone":"+919812345678",
                "whatsapp":"+919812345678",
                "email":"sara.english@example.com",
                "location":{"city":"Delhi","area":"South Delhi"},
                "qualifications":[{"degree":"M.A English Literature","institution":"Delhi University","year":2016}],
                "experienceYears":7,
                "subjects":[{"subject":"English","gradeLevels":["Elementary","High School","College"]}],
                "languages":["English","Hindi"],
                "pricing":{"hourlyMin":600,"hourlyMax":900},
                "teachingModes":{"homeVisit":false,"online":true,"atTutorPlace":true},
                "availability":[{"day":"Sat","timeWindows":[{"start":"10:00","end":"14:00"}]}],
                "contactPreferences":{"bestTimes":["Weekend"],"avgResponseTime":"4h"},
                "ratings":{"average":4.6,"count":30,"breakdown":{"5":20,"4":8,"3":2,"2":0,"1":0}},
                "reviews":[],
                "about":{"bio":"Certified English tutor specializing in literature and language skills. Help students excel in communication and writing with interactive methods.","philosophy":"Interactive and engaging learning","reasons":"Student success and confidence building is my passion"},
                "areasServed":["South Delhi","Central Delhi","Gurgaon"],
                "createdAt":1627815600,
                "updatedAt":1692082200,
                "premium":false
            },
            {
                "id":"t3",
                "status":"approved",
                "name":"Vikram Rao",
                "photoUrl":"/images/tutors/vikram.jpg",
                "phone":"+919855566677",
                "whatsapp":"+919855566677",
                "email":"vikram.physics@example.com",
                "location":{"city":"Bengaluru","area":"Whitefield"},
                "qualifications":[{"degree":"Ph.D Physics","institution":"IISc Bangalore","year":2020}],
                "experienceYears":3,
                "subjects":[{"subject":"Physics","gradeLevels":["High School","College"]}],
                "languages":["English","Kannada"],
                "pricing":{"hourlyMin":1000,"hourlyMax":1500},
                "teachingModes":{"homeVisit":false,"online":true,"atTutorPlace":false},
                "availability":[{"day":"Sun","timeWindows":[{"start":"09:00","end":"12:00"}]}],
                "contactPreferences":{"bestTimes":["Morning"],"avgResponseTime":"1h"},
                "ratings":{"average":4.9,"count":15,"breakdown":{"5":14,"4":1,"3":0,"2":0,"1":0}},
                "reviews":[],
                "about":{"bio":"Physics researcher turned passionate tutor. Making complex physics concepts accessible and interesting for all students through hands-on learning.","philosophy":"Hands-on learning with real world examples","reasons":"Inspire next generation of scientists and innovators"},
                "areasServed":["Online Worldwide"],
                "createdAt":1627815600,
                "updatedAt":1692082200,
                "premium":false
            },
            {
                "id":"t4",
                "status":"approved",
                "name":"Priya Sharma",
                "photoUrl":"/images/tutors/priya.jpg",
                "phone":"+919123456789",
                "whatsapp":"+919123456789",
                "email":"priya.chemistry@example.com",
                "location":{"city":"Pune","area":"Koregaon Park"},
                "qualifications":[{"degree":"M.Sc Chemistry","institution":"University of Pune","year":2019}],
                "experienceYears":4,
                "subjects":[{"subject":"Chemistry","gradeLevels":["High School","College"]}],
                "languages":["English","Hindi","Marathi"],
                "pricing":{"hourlyMin":700,"hourlyMax":1100},
                "teachingModes":{"homeVisit":true,"online":true,"atTutorPlace":true},
                "availability":[{"day":"Wed","timeWindows":[{"start":"15:00","end":"19:00"}]}],
                "contactPreferences":{"bestTimes":["Afternoon","Evening"],"avgResponseTime":"3h"},
                "ratings":{"average":4.7,"count":25,"breakdown":{"5":18,"4":5,"3":2,"2":0,"1":0}},
                "reviews":[],
                "about":{"bio":"Chemistry expert with focus on practical applications. Help students understand chemistry through experiments and real-world connections.","philosophy":"Learning by doing and experimenting","reasons":"Chemistry is everywhere around us and impacts our daily lives"},
                "areasServed":["Koregaon Park","Viman Nagar","Kalyani Nagar","Hadapsar"],
                "createdAt":1627815600,
                "updatedAt":1692082200,
                "premium":false
            },
            {
                "id":"t5",
                "status":"approved",
                "name":"Rajesh Kumar",
                "photoUrl":"/images/tutors/rajesh.jpg",
                "phone":"+919988776655",
                "whatsapp":"+919988776655",
                "email":"rajesh.computer@example.com",
                "location":{"city":"Hyderabad","area":"Madhapur"},
                "qualifications":[{"degree":"B.Tech Computer Science","institution":"BITS Pilani","year":2015}],
                "experienceYears":8,
                "subjects":[{"subject":"Computer Science","gradeLevels":["High School","College","Professional"]}],
                "languages":["English","Hindi","Telugu"],
                "pricing":{"hourlyMin":900,"hourlyMax":1400},
                "teachingModes":{"homeVisit":false,"online":true,"atTutorPlace":false},
                "availability":[{"day":"Fri","timeWindows":[{"start":"18:00","end":"21:00"}]}],
                "contactPreferences":{"bestTimes":["Evening"],"avgResponseTime":"2h"},
                "ratings":{"average":4.8,"count":38,"breakdown":{"5":30,"4":6,"3":2,"2":0,"1":0}},
                "reviews":[],
                "about":{"bio":"Software engineer turned educator specializing in programming and computer science concepts. Help students master coding skills for academic and career success.","philosophy":"Learn by building real projects","reasons":"Technology education is the future"},
                "areasServed":["Online Worldwide","Hyderabad"],
                "createdAt":1627815600,
                "updatedAt":1692082200,
                "premium":false
            }
        ];
        
        this.filteredTutors = [...this.tutors];
    }

    // Setup event listeners
    setupEventListeners() {
        // Wait for DOM to be fully ready
        setTimeout(() => {
            this.initializeEventListeners();
        }, 100);
    }

    initializeEventListeners() {
        // Navigation
        document.querySelectorAll('.nav-item').forEach(item => {
            item.addEventListener('click', (e) => {
                e.preventDefault();
                const page = e.target.getAttribute('data-page');
                if (page) {
                    this.navigateTo(page);
                }
            });
        });

        // Search
        const searchBtn = document.getElementById('search-btn');
        const searchInput = document.getElementById('search-input');
        
        if (searchBtn) {
            searchBtn.addEventListener('click', (e) => {
                e.preventDefault();
                this.handleSearch();
            });
        }
        
        if (searchInput) {
            searchInput.addEventListener('keypress', (e) => {
                if (e.key === 'Enter') {
                    e.preventDefault();
                    this.handleSearch();
                }
            });
        }

        // Category buttons
        document.querySelectorAll('.category-card').forEach(card => {
            card.addEventListener('click', (e) => {
                e.preventDefault();
                const subject = e.currentTarget.getAttribute('data-subject');
                if (subject) {
                    this.searchByCategory(subject);
                }
            });
        });

        // Filter toggle
        const filterToggle = document.getElementById('filter-toggle');
        if (filterToggle) {
            filterToggle.addEventListener('click', (e) => {
                e.preventDefault();
                const filterPanel = document.getElementById('filter-panel');
                if (filterPanel) {
                    filterPanel.classList.toggle('active');
                }
            });
        }

        // Filter controls
        const applyFilters = document.getElementById('apply-filters');
        const clearFilters = document.getElementById('clear-filters');
        
        if (applyFilters) {
            applyFilters.addEventListener('click', (e) => {
                e.preventDefault();
                this.applyFilters();
            });
        }
        
        if (clearFilters) {
            clearFilters.addEventListener('click', (e) => {
                e.preventDefault();
                this.clearFilters();
            });
        }

        // Modal controls
        const modalClose = document.getElementById('modal-close');
        const modalBackdrop = document.getElementById('modal-backdrop');
        
        if (modalClose) {
            modalClose.addEventListener('click', (e) => {
                e.preventDefault();
                this.closeModal();
            });
        }
        
        if (modalBackdrop) {
            modalBackdrop.addEventListener('click', (e) => {
                e.preventDefault();
                this.closeModal();
            });
        }

        // Tutor Registration Modal
        const becomeTutorBtn = document.getElementById('become-tutor-btn');
        const registrationClose = document.getElementById('registration-close');
        const registrationBackdrop = document.getElementById('registration-backdrop');
        
        if (becomeTutorBtn) {
            becomeTutorBtn.addEventListener('click', (e) => {
                e.preventDefault();
                this.showTutorRegistration();
            });
        }
        
        if (registrationClose) {
            registrationClose.addEventListener('click', (e) => {
                e.preventDefault();
                this.closeTutorRegistration();
            });
        }
        
        if (registrationBackdrop) {
            registrationBackdrop.addEventListener('click', (e) => {
                e.preventDefault();
                this.closeTutorRegistration();
            });
        }

        // Registration form navigation
        this.setupRegistrationFormListeners();

        // Install prompt
        const installBtn = document.getElementById('install-app');
        const dismissBtn = document.getElementById('install-dismiss');
        
        if (installBtn) {
            installBtn.addEventListener('click', (e) => {
                e.preventDefault();
                this.installPWA();
            });
        }
        
        if (dismissBtn) {
            dismissBtn.addEventListener('click', (e) => {
                e.preventDefault();
                this.dismissInstallPrompt();
            });
        }
    }

    // Setup registration form listeners
    setupRegistrationFormListeners() {
        // Step navigation buttons
        const nextStep1 = document.getElementById('next-step-1');
        const nextStep2 = document.getElementById('next-step-2');
        const prevStep2 = document.getElementById('prev-step-2');
        const nextStep3 = document.getElementById('next-step-3');
        const prevStep3 = document.getElementById('prev-step-3');
        const prevStep4 = document.getElementById('prev-step-4');
        const submitRegistration = document.getElementById('submit-registration');

        if (nextStep1) {
            nextStep1.addEventListener('click', (e) => {
                e.preventDefault();
                if (this.validateStep1()) {
                    this.goToStep(2);
                }
            });
        }

        if (nextStep2) {
            nextStep2.addEventListener('click', (e) => {
                e.preventDefault();
                if (this.validateStep2()) {
                    this.goToStep(3);
                }
            });
        }

        if (prevStep2) {
            prevStep2.addEventListener('click', (e) => {
                e.preventDefault();
                this.goToStep(1);
            });
        }

        if (nextStep3) {
            nextStep3.addEventListener('click', (e) => {
                e.preventDefault();
                if (this.validateStep3()) {
                    this.goToStep(4);
                }
            });
        }

        if (prevStep3) {
            prevStep3.addEventListener('click', (e) => {
                e.preventDefault();
                this.goToStep(2);
            });
        }

        if (prevStep4) {
            prevStep4.addEventListener('click', (e) => {
                e.preventDefault();
                this.goToStep(3);
            });
        }

        if (submitRegistration) {
            submitRegistration.addEventListener('click', (e) => {
                e.preventDefault();
                if (this.validateStep4()) {
                    this.submitTutorRegistration();
                }
            });
        }
    }

    // PWA Setup
    setupPWA() {
        // Handle PWA install prompt
        window.addEventListener('beforeinstallprompt', (e) => {
            e.preventDefault();
            this.deferredPrompt = e;
            
            // Show install prompt after 3 seconds
            setTimeout(() => {
                const installPrompt = document.getElementById('install-prompt');
                if (installPrompt) {
                    installPrompt.classList.remove('hidden');
                }
            }, 3000);
        });

        // Register service worker
        if ('serviceWorker' in navigator) {
            navigator.serviceWorker.register('/sw.js')
                .then(() => console.log('SW registered'))
                .catch(() => console.log('SW registration failed'));
        }
    }

    // Navigation
    navigateTo(page) {
        console.log('Navigating to:', page);
        
        // Update nav items
        document.querySelectorAll('.nav-item').forEach(item => {
            item.classList.remove('active');
            if (item.getAttribute('data-page') === page) {
                item.classList.add('active');
            }
        });

        // Show/hide pages
        document.querySelectorAll('.page').forEach(pageEl => {
            pageEl.classList.remove('active');
        });
        
        const targetPage = document.getElementById(`${page}-page`);
        if (targetPage) {
            targetPage.classList.add('active');
            console.log('Activated page:', page);
        } else {
            console.error('Page not found:', `${page}-page`);
        }

        this.currentPage = page;

        // Render page content
        switch (page) {
            case 'home':
                this.renderHomePage();
                break;
            case 'browse':
                this.renderBrowsePage();
                break;
            case 'favorites':
                this.renderFavoritesPage();
                break;
        }
    }

    // Search functionality
    handleSearch() {
        const searchInput = document.getElementById('search-input');
        if (!searchInput) return;
        
        const query = searchInput.value.trim().toLowerCase();
        console.log('Search query:', query);
        
        if (query) {
            this.filteredTutors = this.tutors.filter(tutor => {
                return tutor.name.toLowerCase().includes(query) ||
                       tutor.subjects.some(s => s.subject.toLowerCase().includes(query)) ||
                       tutor.location.city.toLowerCase().includes(query) ||
                       tutor.location.area.toLowerCase().includes(query);
            });
            
            console.log('Filtered tutors:', this.filteredTutors.length);
            this.navigateTo('browse');
            this.showToast(`Found ${this.filteredTutors.length} tutors for "${query}"`, 'success');
        } else {
            this.filteredTutors = [...this.tutors];
            this.navigateTo('browse');
        }
    }

    searchByCategory(subject) {
        console.log('Searching by category:', subject);
        
        this.filteredTutors = this.tutors.filter(tutor => {
            return tutor.subjects.some(s => {
                // Check if the subject matches
                const subjectMatches = s.subject.toLowerCase().includes(subject.toLowerCase());
                // Check if any grade level includes the subject term
                const gradeLevelMatches = s.gradeLevels.some(level => level.toLowerCase().includes(subject.toLowerCase()));
                return subjectMatches || gradeLevelMatches;
            });
        });
        
        console.log('Category filtered tutors:', this.filteredTutors.length);
        this.navigateTo('browse');
        this.showToast(`Showing ${this.filteredTutors.length} ${subject} tutors`, 'success');
    }

    // Filter functionality
    applyFilters() {
        const subjectFilter = document.getElementById('subject-filter');
        const cityFilter = document.getElementById('city-filter');
        
        if (!subjectFilter || !cityFilter) return;
        
        const subjectValue = subjectFilter.value;
        const cityValue = cityFilter.value;
        
        this.filteredTutors = this.tutors.filter(tutor => {
            const matchesSubject = !subjectValue || 
                tutor.subjects.some(s => s.subject === subjectValue);
            const matchesCity = !cityValue || 
                tutor.location.city === cityValue;
                
            return matchesSubject && matchesCity;
        });
        
        this.renderBrowsePage();
        const filterPanel = document.getElementById('filter-panel');
        if (filterPanel) {
            filterPanel.classList.remove('active');
        }
        this.showToast(`Applied filters - ${this.filteredTutors.length} tutors found`, 'success');
    }

    clearFilters() {
        const subjectFilter = document.getElementById('subject-filter');
        const cityFilter = document.getElementById('city-filter');
        
        if (subjectFilter) subjectFilter.value = '';
        if (cityFilter) cityFilter.value = '';
        
        this.filteredTutors = [...this.tutors];
        this.renderBrowsePage();
        
        const filterPanel = document.getElementById('filter-panel');
        if (filterPanel) {
            filterPanel.classList.remove('active');
        }
        this.showToast('Filters cleared', 'success');
    }

    // Render pages
    renderHomePage() {
        // Home page is mostly static, no additional rendering needed
        console.log('Rendering home page');
    }

    renderBrowsePage() {
        const tutorsGrid = document.getElementById('tutors-grid');
        if (!tutorsGrid) {
            console.error('Tutors grid element not found');
            return;
        }

        console.log('Rendering browse page with', this.filteredTutors.length, 'tutors');

        if (this.filteredTutors.length === 0) {
            tutorsGrid.innerHTML = `
                <div class="empty-state">
                    <h3>No tutors found</h3>
                    <p>Try adjusting your search or filters</p>
                </div>
            `;
            return;
        }

        tutorsGrid.innerHTML = this.filteredTutors.map(tutor => this.createTutorCard(tutor)).join('');
        
        // Add event listeners for tutor cards
        this.setupTutorCardListeners();
    }

    renderFavoritesPage() {
        const favoritesGrid = document.getElementById('favorites-grid');
        if (!favoritesGrid) {
            console.error('Favorites grid element not found');
            return;
        }

        const favoriteTutors = this.tutors.filter(tutor => this.favorites.includes(tutor.id));
        console.log('Rendering favorites page with', favoriteTutors.length, 'favorites');

        if (favoriteTutors.length === 0) {
            favoritesGrid.innerHTML = `
                <div class="empty-state">
                    <h3>No favorites yet</h3>
                    <p>Add tutors to your favorites to see them here</p>
                </div>
            `;
            return;
        }

        favoritesGrid.innerHTML = favoriteTutors.map(tutor => this.createTutorCard(tutor)).join('');
        
        // Add event listeners for tutor cards
        this.setupTutorCardListeners();
    }

    // Create tutor card HTML
    createTutorCard(tutor) {
        const isFavorite = this.favorites.includes(tutor.id);
        const subjects = tutor.subjects.map(s => s.subject).join(', ');
        const rating = '★'.repeat(Math.floor(tutor.ratings.average)) + '☆'.repeat(5 - Math.floor(tutor.ratings.average));
        
        return `
            <div class="tutor-card" data-tutor-id="${tutor.id}">
                <button class="favorite-btn ${isFavorite ? 'active' : ''}" data-tutor-id="${tutor.id}">
                    <svg width="20" height="20" fill="currentColor" viewBox="0 0 20 20">
                        <path d="M3.172 5.172a4 4 0 015.656 0L10 6.343l1.172-1.171a4 4 0 115.656 5.656L10 17.657l-6.828-6.829a4 4 0 010-5.656z"></path>
                    </svg>
                </button>
                
                <div class="tutor-header">
                    <div class="tutor-avatar">
                        ${tutor.name.charAt(0)}
                    </div>
                    <div class="tutor-info">
                        <h4>${tutor.name}</h4>
                        <div class="tutor-location">${tutor.location.area}, ${tutor.location.city}</div>
                    </div>
                </div>
                
                <div class="tutor-subjects">
                    ${tutor.subjects.map(s => `<span class="subject-tag">${s.subject}</span>`).join('')}
                </div>
                
                <div class="tutor-rating">
                    <span class="rating-stars">${rating}</span>
                    <span class="rating-text">${tutor.ratings.average} (${tutor.ratings.count} reviews)</span>
                </div>
                
                <div class="tutor-pricing">
                    ₹${tutor.pricing.hourlyMin} - ₹${tutor.pricing.hourlyMax} /hour
                </div>
                
                <div class="tutor-actions">
                    <button class="btn btn--primary view-profile-btn" data-tutor-id="${tutor.id}">
                        View Profile
                    </button>
                    <button class="btn btn--success contact-btn" data-tutor-id="${tutor.id}" data-contact-type="whatsapp">
                        WhatsApp
                    </button>
                </div>
            </div>
        `;
    }

    // Setup event listeners for tutor cards
    setupTutorCardListeners() {
        // View profile buttons
        document.querySelectorAll('.view-profile-btn').forEach(btn => {
            btn.addEventListener('click', (e) => {
                e.preventDefault();
                const tutorId = e.target.getAttribute('data-tutor-id');
                this.showTutorProfile(tutorId);
            });
        });

        // Favorite buttons
        document.querySelectorAll('.favorite-btn').forEach(btn => {
            btn.addEventListener('click', (e) => {
                e.preventDefault();
                e.stopPropagation();
                const tutorId = e.currentTarget.getAttribute('data-tutor-id');
                this.toggleFavorite(tutorId);
            });
        });

        // Contact buttons
        document.querySelectorAll('.contact-btn').forEach(btn => {
            btn.addEventListener('click', (e) => {
                e.preventDefault();
                const tutorId = e.target.getAttribute('data-tutor-id');
                const contactType = e.target.getAttribute('data-contact-type');
                this.contactTutor(tutorId, contactType);
            });
        });
    }

    // Show tutor profile modal
    showTutorProfile(tutorId) {
        const tutor = this.tutors.find(t => t.id === tutorId);
        if (!tutor) return;

        const modal = document.getElementById('tutor-modal');
        const modalBody = document.getElementById('modal-body');
        
        if (!modal || !modalBody) return;
        
        modalBody.innerHTML = `
            <div class="tutor-profile">
                <div class="profile-header">
                    <div class="tutor-avatar" style="width: 80px; height: 80px; font-size: 24px;">
                        ${tutor.name.charAt(0)}
                    </div>
                    <div class="profile-info">
                        <h2>${tutor.name}</h2>
                        <p class="profile-location">${tutor.location.area}, ${tutor.location.city}</p>
                        <div class="profile-rating">
                            <span class="rating-stars">${'★'.repeat(Math.floor(tutor.ratings.average))}${'☆'.repeat(5 - Math.floor(tutor.ratings.average))}</span>
                            <span class="rating-text">${tutor.ratings.average} (${tutor.ratings.count} reviews)</span>
                        </div>
                    </div>
                </div>
                
                <div class="profile-section">
                    <h3>About</h3>
                    <p>${tutor.about.bio}</p>
                </div>
                
                <div class="profile-section">
                    <h3>Qualifications</h3>
                    ${tutor.qualifications.map(q => `
                        <div class="qualification">
                            <strong>${q.degree}</strong><br>
                            ${q.institution} (${q.year})
                        </div>
                    `).join('')}
                </div>
                
                <div class="profile-section">
                    <h3>Subjects & Levels</h3>
                    ${tutor.subjects.map(s => `
                        <div class="subject-item">
                            <strong>${s.subject}</strong>: ${s.gradeLevels.join(', ')}
                        </div>
                    `).join('')}
                </div>
                
                <div class="profile-section">
                    <h3>Teaching Details</h3>
                    <div class="teaching-info">
                        <p><strong>Experience:</strong> ${tutor.experienceYears} years</p>
                        <p><strong>Languages:</strong> ${tutor.languages.join(', ')}</p>
                        <p><strong>Pricing:</strong> ₹${tutor.pricing.hourlyMin} - ₹${tutor.pricing.hourlyMax} /hour</p>
                        <p><strong>Modes:</strong> 
                            ${Object.entries(tutor.teachingModes).filter(([_, available]) => available).map(([mode, _]) => {
                                const modeNames = {
                                    'homeVisit': 'Home Visit',
                                    'online': 'Online',
                                    'atTutorPlace': 'At Tutor Place'
                                };
                                return modeNames[mode];
                            }).join(', ')}
                        </p>
                        <p><strong>Areas Served:</strong> ${tutor.areasServed.join(', ')}</p>
                    </div>
                </div>
                
                <div class="profile-actions">
                    <button class="btn btn--success contact-btn" data-tutor-id="${tutor.id}" data-contact-type="whatsapp">
                        <svg width="20" height="20" fill="currentColor" viewBox="0 0 24 24">
                            <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.890-5.335 11.893-11.893A11.821 11.821 0 0020.885 3.105"/>
                        </svg>
                        WhatsApp
                    </button>
                    <button class="btn btn--primary contact-btn" data-tutor-id="${tutor.id}" data-contact-type="phone">
                        <svg width="20" height="20" fill="currentColor" viewBox="0 0 20 20">
                            <path d="M2 3a1 1 0 011-1h2.153a1 1 0 01.986.836l.74 4.435a1 1 0 01-.54 1.06l-1.548.773a11.037 11.037 0 006.105 6.105l.774-1.548a1 1 0 011.059-.54l4.435.74a1 1 0 01.836.986V17a1 1 0 01-1 1h-2C7.82 18 2 12.18 2 5V3z"></path>
                        </svg>
                        Call
                    </button>
                    <button class="btn btn--secondary contact-btn" data-tutor-id="${tutor.id}" data-contact-type="sms">
                        <svg width="20" height="20" fill="currentColor" viewBox="0 0 20 20">
                            <path fill-rule="evenodd" d="M18 10c0 3.866-3.582 7-8 7a8.841 8.841 0 01-4.083-.98L2 17l1.338-3.123C2.493 12.767 2 11.434 2 10c0-3.866 3.582-7 8-7s8 3.134 8 7zM7 9H5v2h2V9zm8 0h-2v2h2V9zM9 9h2v2H9V9z" clip-rule="evenodd"></path>
                        </svg>
                        SMS
                    </button>
                </div>
            </div>
        `;
        
        // Add event listeners for contact buttons in modal
        modalBody.querySelectorAll('.contact-btn').forEach(btn => {
            btn.addEventListener('click', (e) => {
                e.preventDefault();
                const tutorId = e.currentTarget.getAttribute('data-tutor-id');
                const contactType = e.currentTarget.getAttribute('data-contact-type');
                this.contactTutor(tutorId, contactType);
            });
        });
        
        modal.classList.remove('hidden');
    }

    // Close modal
    closeModal() {
        const modal = document.getElementById('tutor-modal');
        if (modal) {
            modal.classList.add('hidden');
        }
    }

    // Contact tutor with limit checking
    contactTutor(tutorId, contactType) {
        // Check contact limit
        if (this.contactCount >= this.maxFreeContacts) {
            this.showContactLimitMessage();
            return;
        }

        const tutor = this.tutors.find(t => t.id === tutorId);
        if (!tutor) return;

        let url;
        const message = `Hi ${tutor.name}, I found your profile on TutorConnectify and I'm interested in ${tutor.subjects.map(s => s.subject).join(', ')} tutoring. Can we discuss?`;
        
        switch (contactType) {
            case 'whatsapp':
                url = `https://wa.me/${tutor.whatsapp.replace('+', '')}?text=${encodeURIComponent(message)}`;
                break;
            case 'phone':
                url = `tel:${tutor.phone}`;
                break;
            case 'sms':
                url = `sms:${tutor.phone}?body=${encodeURIComponent(message)}`;
                break;
        }
        
        if (url) {
            window.open(url, '_blank');
            this.contactCount++;
            this.saveContactCount();
            
            const remaining = this.maxFreeContacts - this.contactCount;
            if (remaining > 0) {
                this.showToast(`Contacting ${tutor.name}. ${remaining} free contacts remaining.`, 'success');
            } else {
                this.showToast(`Contacting ${tutor.name}. Contact limit reached - register for unlimited access!`, 'warning');
            }
        }
    }

    // Show contact limit message
    showContactLimitMessage() {
        this.showToast('Contact limit reached! Register as a student for unlimited access to tutors.', 'error');
        // Could show a registration modal here
    }

    // Tutor Registration Modal
    showTutorRegistration() {
        const modal = document.getElementById('tutor-registration-modal');
        if (modal) {
            modal.classList.remove('hidden');
            this.currentRegistrationStep = 1;
            this.goToStep(1);
        }
    }

    closeTutorRegistration() {
        const modal = document.getElementById('tutor-registration-modal');
        if (modal) {
            modal.classList.add('hidden');
        }
    }

    goToStep(step) {
        // Update step indicator
        document.querySelectorAll('.step').forEach((stepEl, index) => {
            stepEl.classList.toggle('active', index + 1 <= step);
        });

        // Show/hide form steps
        document.querySelectorAll('.form-step').forEach((stepEl, index) => {
            stepEl.classList.toggle('active', index + 1 === step);
        });

        this.currentRegistrationStep = step;
    }

    // Form validation
    validateStep1() {
        const name = document.getElementById('tutor-name')?.value.trim();
        const email = document.getElementById('tutor-email')?.value.trim();
        const phone = document.getElementById('tutor-phone')?.value.trim();

        if (!name || !email || !phone) {
            this.showToast('Please fill in all required fields', 'error');
            return false;
        }

        if (!email.includes('@')) {
            this.showToast('Please enter a valid email address', 'error');
            return false;
        }

        return true;
    }

    validateStep2() {
        const city = document.getElementById('tutor-city')?.value.trim();
        const area = document.getElementById('tutor-area')?.value.trim();
        const experience = document.getElementById('tutor-experience')?.value;

        if (!city || !area || !experience) {
            this.showToast('Please fill in all required fields', 'error');
            return false;
        }

        if (experience < 0 || experience > 50) {
            this.showToast('Please enter a valid experience (0-50 years)', 'error');
            return false;
        }

        return true;
    }

    validateStep3() {
        const subject = document.getElementById('tutor-subjects')?.value;
        const pricing = document.getElementById('tutor-pricing')?.value;
        const onlineMode = document.getElementById('mode-online')?.checked;
        const homeMode = document.getElementById('mode-home')?.checked;

        if (!subject) {
            this.showToast('Please select a subject', 'error');
            return false;
        }

        if (!pricing || pricing < 100 || pricing > 10000) {
            this.showToast('Please enter a valid hourly rate (₹100-₹10,000)', 'error');
            return false;
        }

        if (!onlineMode && !homeMode) {
            this.showToast('Please select at least one teaching mode', 'error');
            return false;
        }

        return true;
    }

    validateStep4() {
        const bio = document.getElementById('tutor-bio')?.value.trim();
        const qualification = document.getElementById('tutor-qualification')?.value.trim();

        if (!bio || bio.length < 50) {
            this.showToast('Please write at least 50 characters about yourself', 'error');
            return false;
        }

        if (!qualification) {
            this.showToast('Please enter your highest qualification', 'error');
            return false;
        }

        return true;
    }

    // Submit tutor registration
    submitTutorRegistration() {
        const formData = {
            name: document.getElementById('tutor-name').value,
            email: document.getElementById('tutor-email').value,
            phone: document.getElementById('tutor-phone').value,
            city: document.getElementById('tutor-city').value,
            area: document.getElementById('tutor-area').value,
            experience: document.getElementById('tutor-experience').value,
            subject: document.getElementById('tutor-subjects').value,
            pricing: document.getElementById('tutor-pricing').value,
            onlineMode: document.getElementById('mode-online').checked,
            homeMode: document.getElementById('mode-home').checked,
            bio: document.getElementById('tutor-bio').value,
            qualification: document.getElementById('tutor-qualification').value
        };

        console.log('Tutor registration data:', formData);
        
        // Simulate API call
        setTimeout(() => {
            this.showToast('Registration submitted successfully! We\'ll review your application and contact you within 24 hours.', 'success');
            this.closeTutorRegistration();
        }, 1000);
    }

    // Favorites management
    toggleFavorite(tutorId) {
        const index = this.favorites.indexOf(tutorId);
        const tutor = this.tutors.find(t => t.id === tutorId);
        
        if (index === -1) {
            this.favorites.push(tutorId);
            this.showToast(`${tutor.name} added to favorites`, 'success');
        } else {
            this.favorites.splice(index, 1);
            this.showToast(`${tutor.name} removed from favorites`, 'success');
        }
        
        this.saveFavorites();
        
        // Update favorite button states
        document.querySelectorAll(`[data-tutor-id="${tutorId}"].favorite-btn`).forEach(btn => {
            btn.classList.toggle('active');
        });
        
        // Re-render favorites page if currently active
        if (this.currentPage === 'favorites') {
            this.renderFavoritesPage();
        }
    }

    // Local storage for favorites
    loadFavorites() {
        try {
            const stored = localStorage.getItem('tutorconnectify-favorites');
            return stored ? JSON.parse(stored) : [];
        } catch (e) {
            return [];
        }
    }

    saveFavorites() {
        try {
            localStorage.setItem('tutorconnectify-favorites', JSON.stringify(this.favorites));
        } catch (e) {
            console.error('Could not save favorites');
        }
    }

    // Contact count management
    loadContactCount() {
        try {
            const stored = localStorage.getItem('tutorconnectify-contact-count');
            return stored ? parseInt(stored, 10) : 0;
        } catch (e) {
            return 0;
        }
    }

    saveContactCount() {
        try {
            localStorage.setItem('tutorconnectify-contact-count', this.contactCount.toString());
        } catch (e) {
            console.error('Could not save contact count');
        }
    }

    // PWA Installation
    installPWA() {
        if (this.deferredPrompt) {
            this.deferredPrompt.prompt();
            this.deferredPrompt.userChoice.then((choiceResult) => {
                if (choiceResult.outcome === 'accepted') {
                    this.showToast('TutorConnectify installed successfully!', 'success');
                }
                this.deferredPrompt = null;
                this.dismissInstallPrompt();
            });
        }
    }

    dismissInstallPrompt() {
        const installPrompt = document.getElementById('install-prompt');
        if (installPrompt) {
            installPrompt.classList.add('hidden');
        }
    }

    // Toast notifications
    showToast(message, type = 'success') {
        const toastContainer = document.getElementById('toast-container');
        if (!toastContainer) return;

        const toast = document.createElement('div');
        toast.className = `toast ${type}`;
        toast.textContent = message;
        
        toastContainer.appendChild(toast);
        
        setTimeout(() => {
            if (toast.parentNode) {
                toast.remove();
            }
        }, 4000);
    }
}

// Initialize app when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    console.log('DOM loaded, initializing app...');
    window.tutorApp = new TutorConnectifyApp();
});

// Register service worker
if ('serviceWorker' in navigator) {
    window.addEventListener('load', () => {
        navigator.serviceWorker.register('/sw.js', { scope: '/' })
            .then((registration) => {
                console.log('SW registered: ', registration);
            })
            .catch((registrationError) => {
                console.log('SW registration failed: ', registrationError);
            });
    });
}